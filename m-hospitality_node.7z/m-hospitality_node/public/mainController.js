var app = angular.module('myApp', []);
app.controller('MainController', function($scope,$http) {
	$scope.active='';	
	
	$scope.forage = function(dateBorn){
		var dborn = new Date(dateBorn).getTime()/3600000;
		var currd = new Date().getTime()/3600000;
		var age = (currd - dborn)/(24*365);
		return Math.ceil(age,0);
	}
	$http({
          method: 'GET',
          url: '/players'
        }).then(function successCallback(response) {
			$scope.players = response.data.player;
			$scope.playersfavor = response.data.player;
			$scope.player = $scope.players[0];
			$scope.age = $scope.forage($scope.player.dateBorn);
			$scope.playerid = $scope.player.idPlayer;
			if ($scope.player.intLoved == '0'){
			$scope.asterisk = 'far fa-star fa-lg'
			$scope.mycolor = 'none';
		}
		else if ($scope.player.intLoved == '1'){
			$scope.asterisk = 'fas fa-star fa-lg';
			$scope.mycolor = '#FFFF33';
		}
        }, function errorCallback(response) {
          //alert(response);
        });
		
	$scope.paikths = function(player){
		$scope.player = player;
		if ($scope.player.intLoved == '0'){
			$scope.asterisk = 'far fa-star fa-lg'
			$scope.mycolor = 'none';
		}
		else if ($scope.player.intLoved == '1'){
			$scope.asterisk = 'fas fa-star fa-lg';
			$scope.mycolor = '#FFFF33';
		}
		$scope.age = $scope.forage(player.dateBorn); 
		
		$scope.playerid = player.idPlayer;
		
	}
	
	$scope.add = function(player){
		$scope.mycolor = '#FFFF33';
		$scope.asterisk = 'fas fa-star fa-lg';
		 $http({
          method: 'PUT',
          url: '/playerupdate/'+player.idPlayer+'/1'
        }).then(function successCallback(response) {
			$scope.playersfavor = response.data.player;
			$scope.players = response.data.player;
        }, function errorCallback(response) {
          //alert(response);
        });
	}
	
	$scope.remove = function(player){
		 $http({
          method: 'PUT',
          url: '/playerupdate/'+player.idPlayer+'/0'
        }).then(function successCallback(response) {
			$scope.players = response.data.player;
			$scope.playersfavor = response.data.player;
			$scope.mycolor = 'none';
		    $scope.asterisk = 'far fa-star fa-lg';
        }, function errorCallback(response) {
          //alert(response);
        });
	}
});
﻿var dateBorn = "1986-09-30";

var dborn = new Date(dateBorn).getTime()/3600000;
var currd = new Date().getTime()/3600000;
var age = (currd - dborn)/(24*365);
//age = age + 1;
console.log(dborn);
console.log(currd);
console.log(Math.ceil(age,0));

// d-test

/*var dl='2018/2/5';

var d_end = new Date(dl).getTime()/3600000;
var d_cur = new Date().getTime()/3600000;

console.log(d_cur);
console.log(d_end);*/
 

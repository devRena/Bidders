var express = require('express');
var app = express();
var fs = require('fs');
var myfun = function(file,id,value){
	var A = JSON.parse(fs.readFileSync('./'+file));
	for (var i=0; i<A.player.length; i++){
		if (A.player[i].idPlayer === id){
			A.player[i].intLoved = value;
		}
			
	}
	//console.log(A[p]);
	
	fs.writeFileSync('./'+file, JSON.stringify(A,null,2));
	//console.log(A);
	return A;
}

app.use(express.static('public'));

app.get('/players', function(req,res){

	const fs = require('fs');

	fs.readFile('players.json', (err, data) => {  
		if (err) throw err;
		res.send(JSON.parse(data));
    });
});
app.put('/playerupdate/:id/:favor', function(req,res){
	//console.log(req.params.favor);
	var data = myfun('players.json',req.params.id,req.params.favor);
	res.send(data);
});


app.get('/', function(req, res) {
	res.sendFile(__dirname+'/index.html');
	});
app.listen(1234);